import { TranslationPipe } from './translation.pipe';

describe('TranslationPipe', () => {
  it('create an instance', () => {
    const pipe = new TranslationPipe();
    expect(pipe).toBeTruthy();
  });
});
