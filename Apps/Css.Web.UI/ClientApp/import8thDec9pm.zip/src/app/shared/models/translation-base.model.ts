export class TranslationBase {
    id: number;
    languageId: number;
    menuId: number;
    variableId: number;
    translation: string;
    variableDescription: string;
}
