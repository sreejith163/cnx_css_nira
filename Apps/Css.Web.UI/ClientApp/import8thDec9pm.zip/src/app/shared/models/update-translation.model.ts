import { TranslationBase } from './translation-base.model';

export class UpdateTranslation extends TranslationBase {
    modifiedBy: string;
}
