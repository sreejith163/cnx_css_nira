export class SpinnerStyleOption {
    type: string;
    size: 'default' | 'small' | 'medium' | 'large';
    bdColor: string;
    color: string;
    fullScreen: boolean;
}
