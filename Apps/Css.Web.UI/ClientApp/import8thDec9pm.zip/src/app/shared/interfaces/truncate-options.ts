export interface TextTruncateOptions {
    sliceStart: number;
    sliceEnd: number;
    prepend?: string;
    append?: string;
}
