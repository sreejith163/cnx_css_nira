export enum CssMenu {
    SchedulingCodes = 1,
    AgentCategories = 2,
    Translation = 3,
    ClientName = 4,
    ClientLobGroup = 5,
    SkillGroups = 6,
    SkillTags = 7,
    AgentSchedulingGroup = 8,
    AgentAdmin = 9,
    SchedulingGrid = 10,
    Permissions = 11
}
