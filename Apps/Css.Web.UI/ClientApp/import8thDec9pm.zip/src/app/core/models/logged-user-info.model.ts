export class LoggedUserInfo {
    uid: string;
    displayName: string;
    employeeId: string;
}
