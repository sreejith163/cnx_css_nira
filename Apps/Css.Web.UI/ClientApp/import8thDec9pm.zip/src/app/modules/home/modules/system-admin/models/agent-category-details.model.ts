import { AgentCategoryBase } from './agent-category-base.model';

export class AgentCategoryDetails extends AgentCategoryBase {
    createdDate: string;
    createdBy: string;
    modifiedDate: string;
    modifiedBy: string;
}
