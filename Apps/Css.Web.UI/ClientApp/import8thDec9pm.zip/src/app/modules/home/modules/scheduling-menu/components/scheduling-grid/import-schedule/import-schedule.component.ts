import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { TranslationDetails } from 'src/app/shared/models/translation-details.model';
import { ExcelData } from '../../../models/excel-data.model';
import { SchedulingCodeQueryParams } from '../../../../system-admin/models/scheduling-code-query-params.model';
import { NgxSpinnerService } from 'ngx-spinner';
import { SpinnerOptions } from 'src/app/shared/util/spinner-options.util';
import { forkJoin, SubscriptionLike as ISubscription } from 'rxjs';
import { SchedulingCodeService } from 'src/app/shared/services/scheduling-code.service';
import { SchedulingCode } from '../../../../system-admin/models/scheduling-code.model';
import { AgentSchedulesService } from '../../../services/agent-schedules.service';
import { AgentScheduleChart } from '../../../models/agent-schedule-chart.model';
import { UpdateAgentschedulechart } from '../../../models/update-agent-schedule-chart.model';
import { AgentScheduleType } from '../../../enums/agent-schedule-type.enum';
import { ScheduleChart } from '../../../models/schedule-chart.model';
import { AuthService } from 'src/app/core/services/auth.service';
import { ErrorWarningPopUpComponent } from 'src/app/shared/popups/error-warning-pop-up/error-warning-pop-up.component';
import { ContentType } from 'src/app/shared/enums/content-type.enum';
import { Papa } from 'ngx-papaparse';
import { AgentSchedulesQueryParams } from '../../../models/agent-schedules-query-params.model';
import { AgentSchedulesResponse } from '../../../models/agent-schedules-response.model';
import { ImportShceduleChart } from '../../../models/import-schedule-chart.model';
import { UpdateAgentScheduleMangersChart } from '../../../models/update-agent-schedule-managers-chart.model';
import { ImportScheduleData } from '../../../models/import-schedule-data.model';
import { AgentShceduleMangerData } from '../../../models/agent-schedule-manager-data.model';
import { ManagerExcelData } from '../../../models/manager-excel-data.model';

@Component({
  selector: 'app-import-schedule',
  templateUrl: './import-schedule.component.html',
  styleUrls: ['./import-schedule.component.scss']
})
export class ImportScheduleComponent implements OnInit, OnDestroy {

  uploadFile: string;
  spinner = 'import';
  fileUploaded: File;
  storeData: any;
  worksheet: any;
  fileFormatValidation: boolean;
  fileSubmitted: boolean;
  jsonData: any[] = [];
  scheduleColumns = ['EmployeeId', 'StartDate', 'EndDate', 'ActivityCode', 'StartTime', 'EndTime'];

  getAgentSchedulesSubscription: ISubscription;
  getSchedulingCodesSubscription: ISubscription;
  importAgentScheduleChartSubscription: ISubscription;
  subscriptions: ISubscription[] = [];

  // @Input() agentScheduleId: string;
  @Input() agentScheudleType: AgentScheduleType;
  @Input() translationValues: TranslationDetails[];

  constructor(
    public activeModal: NgbActiveModal,
    private spinnerService: NgxSpinnerService,
    private schedulingCodeService: SchedulingCodeService,
    private agentSchedulesService: AgentSchedulesService,
    private authService: AuthService,
    private modalService: NgbModal,
    private papa: Papa
  ) { }

  ngOnInit(): void {
    // if (this.agentScheudleType === AgentScheduleType.Scheduling) {
    //   this.jsonData = new Array<ImportShceduleChart>();
    // } else {
    //   this.jsonData = new Array<UpdateAgentScheduleMangersChart>();
    // }
  }

  ngOnDestroy() {
    this.subscriptions.forEach(subscription => {
      if (subscription) {
        subscription.unsubscribe();
      }
    });
  }

  import() {
    this.fileSubmitted = true;
    if (this.uploadFile && this.jsonData.length > 0) {
      this.jsonData.map(ele => {
        if (ele.StartTime.split(':')[0].length === 1) {
          ele.StartTime = '0' + ele.StartTime.split(':')[0] + ':' + ele.StartTime.split(':')[1];
        }
        if (ele.StartTime.split(':')[0] === '12') {
          ele.StartTime = '00' + ':' + ele.StartTime.split(':')[1];
        }
        if (ele.EndTime.split(':')[0].length === 1) {
          ele.EndTime = '0' + ele.EndTime.split(':')[0] + ':' + ele.EndTime.split(':')[1];
        }
        if (ele.EndTime.split(':')[0] === '12') {
          ele.EndTime = '00' + ':' + ele.EndTime.split(':')[1];
        }
      });
      if (!this.fileFormatValidation && !this.validateInputRecord()) {
        const employees = new Array<number>();
        this.jsonData.forEach(data => {
          if (employees.filter(x => x === +data.EmployeeId).length === 0) {
            employees.push(+data.EmployeeId);
          }
        });
        this.loadAgentSchedules(employees);
      } else {
        const errorMessage = `“An error occurred upon importing the file. Please check the following”<br>Duplicated Record<br>Incorrect Columns<br>Invalid Date Range and Time`;
        this.showErrorWarningPopUpMessage(errorMessage);
      }
    }
  }

  hasFileSelected() {
    if (this.fileSubmitted) {
      return this.uploadFile ? true : false;
    }
    return true;
  }

  browse(files: any) {
    this.fileUploaded = files[0];
    this.uploadFile = this.fileUploaded.name;
    if (this.uploadFile.split('.')[1] === 'csv') {
      this.readCsvFile();
    } else {
      this.fileFormatValidation = true;
    }
  }

  private readCsvFile() {
    const reader: FileReader = new FileReader();
    reader.readAsText(this.fileUploaded);
    reader.onload = e => {
      const csv = reader.result;
      const results = this.papa.parse(csv as string, { header: false });
      if (results?.data !== undefined && results?.data.length > 0 && results?.errors.length === 0) {
        const csvTableHeader = results.data[0];
        const csvTableData = [...results.data.slice(1, results.data.length)];
        for (const ele of csvTableData) {
          const csvJson = this.agentScheudleType === AgentScheduleType.Scheduling ?
            new ExcelData() : new ManagerExcelData();
          if (ele.length > 0) {
            for (let i = 0; i < ele.length; i++) {
              csvJson[csvTableHeader[i]] = ele[i];
            }
          }
          if (csvJson.EmployeeId) {
            this.jsonData.push(csvJson);
          }
        }
      }
    };
  }

  private validateInputRecord() {
    if (this.jsonData.length > 0) {
      for (const item of this.jsonData) {
        if (this.agentScheudleType === AgentScheduleType.Scheduling) {
          if (item.StartDate && item.EndDate) {
            // if (item.StartDate !== item.EndDate) {
            //   return true;
            // }
            if (!this.jsonData.every(x => x.StartDate === item.StartDate &&
              x.EndDate === item.EndDate)) {
              return true;
            }
          } else {
            return true;
          }
        } else {
          if (!this.jsonData.every(x => x.Date === item.Date)) {
            return true;
          }
        }
        if (this.jsonData.filter(x => this.convertToDateFormat(x.StartTime) === this.convertToDateFormat(item.StartTime) &&
          this.convertToDateFormat(x.EndTime) === this.convertToDateFormat(item.EndTime)).length > 1) {
          return true;
        }
        if (this.jsonData.filter(x => this.convertToDateFormat(x.StartTime) >= this.convertToDateFormat(item.StartTime) &&
          this.convertToDateFormat(x.StartTime) < this.convertToDateFormat(item.EndTime)).length > 1) {
          return true;
        }
        if (this.jsonData.filter(x => this.convertToDateFormat(x.StartTime) > this.convertToDateFormat(item.StartTime) &&
          this.convertToDateFormat(x.EndTime) <= this.convertToDateFormat(item.EndTime)).length > 1) {
          return true;
        }
        if (this.jsonData.find(x => this.convertToDateFormat(x.StartTime) < this.convertToDateFormat(item.StartTime) &&
          this.convertToDateFormat(x.EndTime) >= this.convertToDateFormat(item.EndTime))) {
          return true;
        }
        if (this.jsonData.find(x => this.convertToDateFormat(x.StartTime) < this.convertToDateFormat(item.StartTime) &&
          this.convertToDateFormat(x.EndTime) === this.convertToDateFormat(item.EndTime))) {
          return true;
        }
        if (item) {
          for (const property in item) {
            if (this.scheduleColumns.findIndex(x => x === property) === -1) {
              return true;
            }
          }
        }
        return this.validateTimeFormat(item);
      }
    } else {
      return true;
    }
  }

  private validateTimeFormat(data: ExcelData) {
    if (data.StartTime && data.EndTime) {
      if (data.StartTime.indexOf(':') > -1 && data.StartTime.indexOf(' ') > -1 &&
        data.EndTime.indexOf(':') > -1 && data.EndTime.indexOf(' ') > -1) {
        if (!data.StartTime.split(':')[0] && !data.StartTime.split(':')[1].split(' ')[0] &&
          !data.EndTime.split(':')[0] && !data.EndTime.split(':')[1].split(' ')[0]) {
          return true;
        }
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  // private matchActivitycodes(activityCodes: Array<string>, schedulingCodes: SchedulingCode[]) {
  //   let hasMismatch = false;
  //   if (activityCodes.length > 0) {
  //     for (const index in activityCodes) {
  //       if (schedulingCodes.findIndex(x => x.description === activityCodes[index]) === -1) {
  //         hasMismatch = true;
  //         break;
  //       }
  //     }
  //   }

  //   this.importAgentScheduleChart(schedulingCodes, hasMismatch);
  // }

  private importAgentScheduleChart(scheduleResponse: AgentSchedulesResponse[], schedulingCodes: SchedulingCode[], hasMismatch?: boolean) {
    const model = this.getImportAgentScheduleChartModel(scheduleResponse, schedulingCodes);
    this.spinnerService.show(this.spinner, SpinnerOptions);

    this.importAgentScheduleChartSubscription = this.agentSchedulesService.importAgentScheduleChart(model)
      .subscribe(() => {
        this.spinnerService.hide(this.spinner);
        this.activeModal.close({ partialImport: hasMismatch });
      }, (error) => {
        this.spinnerService.hide(this.spinner);
        console.log(error);
      });

    this.subscriptions.push(this.importAgentScheduleChartSubscription);
  }

  private loadAgentSchedules(employees: number[]) {
    const activityCodes = Array<string>();
    this.jsonData.forEach(element => {
      if (activityCodes.findIndex(x => x === element.ActivityCode) === -1) {
        activityCodes.push(element.ActivityCode);
      }
    });

    const agentScheduleQueryParams = new AgentSchedulesQueryParams();
    if (employees.length > 0) {
      agentScheduleQueryParams.employeeIds = [];
      agentScheduleQueryParams.employeeIds = employees;
    }

    const schedulingCodeQueryParams = new SchedulingCodeQueryParams();
    schedulingCodeQueryParams.skipPageSize = true;
    schedulingCodeQueryParams.fields = activityCodes?.length > 0 ? 'id, description' : undefined;
    schedulingCodeQueryParams.activityCodes = activityCodes?.length > 0 ? activityCodes : undefined;

    const agentSchedule = this.agentSchedulesService.getAgentSchedules(agentScheduleQueryParams);
    const schedulingCodes = this.schedulingCodeService.getSchedulingCodes(schedulingCodeQueryParams);

    this.spinnerService.show(this.spinner, SpinnerOptions);
    forkJoin([agentSchedule, schedulingCodes]).subscribe((data: any) => {
      let scheduleRepsonse;
      let schedulingCodesResponse;

      if (data[0] && Object.entries(data[0]).length !== 0 && data[0].body) {
        scheduleRepsonse = data[0].body as AgentSchedulesResponse;
      }
      if (data[1] && Object.entries(data[1]).length !== 0 && data[1].body) {
        schedulingCodesResponse = data[1].body as SchedulingCode;
      }

      this.spinnerService.hide(this.spinner);
      if (scheduleRepsonse.length > 0 && schedulingCodesResponse.length > 0) {
        if (activityCodes.length === schedulingCodesResponse) {
          this.importAgentScheduleChart(scheduleRepsonse, schedulingCodesResponse, false);
        } else {
          this.importAgentScheduleChart(scheduleRepsonse, schedulingCodesResponse, true);
        }
      } else {
        const errorMessage = `“An error occurred upon importing the file. Please check the following”<br>Duplicated Record<br>Incorrect Columns<br>Invalid Date Range and Time`;
        this.showErrorWarningPopUpMessage(errorMessage);
      }
    }, error => {
      this.spinnerService.hide(this.spinner); console.log(error);
    });
  }

  private getImportAgentScheduleChartModel(schedules: AgentSchedulesResponse[], schedulingCodes: SchedulingCode[]) {
    const chartModel = new ImportShceduleChart();
    chartModel.modifiedBy = this.authService.getLoggedUserInfo()?.displayName;
    for (const employee of schedules) {
      const employeeDetails = this.jsonData.filter(x => +x.EmployeeId === +employee.employeeId);
      const importData = new ImportScheduleData();
      const chartData = new AgentScheduleChart();
      const chartArray = new Array<ScheduleChart>();
      importData.employeeId = employee.employeeId;
      importData.dateFrom = new Date(employeeDetails[0].StartDate) ;
      importData.dateTo = new Date(employeeDetails[0].EndDate);
      employeeDetails.forEach(ele => {
        const data = schedulingCodes.find(x => x.description === ele.ActivityCode);
        if (data) {
          const chart = new ScheduleChart(ele.StartTime, ele.EndTime, data.id);
          chartArray.push(chart);
        }
      });
      for (let i = 0; i < 7; i++) {
        chartData.day = i;
        chartData.charts = chartArray;
        importData.agentScheduleCharts.push(chartData);
      }
      chartModel.importAgentScheduleCharts.push(importData);
    }

    return chartModel;

  }

  private showErrorWarningPopUpMessage(contentMessage: any) {
    const options: NgbModalOptions = { backdrop: 'static', centered: true, size: 'sm' };
    const modalRef = this.modalService.open(ErrorWarningPopUpComponent, options);
    modalRef.componentInstance.headingMessage = 'Error';
    modalRef.componentInstance.contentMessage = contentMessage;
    modalRef.componentInstance.messageType = ContentType.Html;

    return modalRef;
  }

  private convertToDateFormat(time: string) {
    if (time) {
      const count = time.split(' ')[1] === 'pm' ? 12 : undefined;
      if (count) {
        time = (+time.split(':')[0] + 12) + ':' + time.split(':')[1].split(' ')[0];
      } else {
        time = time.split(':')[0] + ':' + time.split(':')[1].split(' ')[0];
      }

      return time;
    }
  }
}
