export class ClientLobGroupBase {
    id: number;
    refId: number;
    name: string;
}
