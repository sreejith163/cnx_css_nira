import { ClientBaseModel } from './client-base.model';

export class AddClient extends ClientBaseModel {
    createdBy: string;
}
