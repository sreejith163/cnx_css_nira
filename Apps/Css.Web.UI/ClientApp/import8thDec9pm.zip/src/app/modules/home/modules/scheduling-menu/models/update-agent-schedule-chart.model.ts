import { AgentScheduleChart } from './agent-schedule-chart.model';

export class UpdateAgentschedulechart {
    agentScheduleCharts: AgentScheduleChart[];
    modifiedBy: string;
}
