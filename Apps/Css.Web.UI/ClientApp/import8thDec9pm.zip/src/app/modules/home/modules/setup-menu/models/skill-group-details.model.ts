import { SkillGroupBase } from './skill-group-base.model';

export class SkillGroupDetails extends SkillGroupBase {
    createdDate: string;
    createdBy: string;
    modifiedDate: string;
    modifiedBy: string;
}
