export class AgentAdminAgentGroup {
    description: string;
    value: string;
}
