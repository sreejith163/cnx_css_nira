import { AgentSchedulingGroupBase } from './agent-scheduling-group-base.model';

export class AgentSchedulingGroupDetails extends AgentSchedulingGroupBase {
    createdDate: string;
    createdBy: string;
    modifiedDate: string;
    modifiedBy: string;
}
