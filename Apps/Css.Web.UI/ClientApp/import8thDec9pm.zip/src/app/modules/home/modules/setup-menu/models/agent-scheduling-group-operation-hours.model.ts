import { WeekDay } from '@angular/common';

export class AgentSchedulingGroupOperationHours {
    day: WeekDay;
    open: string;
    operationHourOpenTypeId: number;
    from: string;
    to: string;
}


