export class SchedulingAgents {
    employeeId: number;
    employeeName: string;
    isChecked: boolean;
}
