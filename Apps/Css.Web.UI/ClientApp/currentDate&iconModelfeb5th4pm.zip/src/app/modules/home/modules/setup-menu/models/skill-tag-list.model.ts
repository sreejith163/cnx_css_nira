export class SkillTagList {
    id: number;
    skillTag: string;
    createdDate: string;
    createdBy: string;
    modifiedBy: string;
    modifiedDate: string;
  }
