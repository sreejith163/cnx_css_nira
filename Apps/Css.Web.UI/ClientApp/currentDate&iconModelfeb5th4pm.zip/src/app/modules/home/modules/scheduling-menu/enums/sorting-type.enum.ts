export enum SortingType {
    'Ascending' = 1,
    'Descending' = 2
}
