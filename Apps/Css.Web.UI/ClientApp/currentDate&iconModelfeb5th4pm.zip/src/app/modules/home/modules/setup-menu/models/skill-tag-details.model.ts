import { SkillTagBase } from './skill-tag-base.model';

export class SkillTagDetails extends SkillTagBase {
    createdDate: string;
    createdBy: string;
    modifiedDate: string;
    modifiedBy: string;
}
