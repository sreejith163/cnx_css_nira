export class Range {
    start: any;
    end: any;

    constructor(start: any, end: any) {
        this.start = start;
        this.end = end;
    }
}
