export class AgentIconFilter {
    codeValue: string;
    startTime: string;
    endTime: string;
    description: string;
}
