import { AgentAdminBase } from './agent-admin-base.model';


export class UpdateAgentAdmin extends AgentAdminBase {
    modifiedBy: string;
}
