import { AgentCategoryBase } from './agent-category-base.model';

export class UpdateAgentCategory extends AgentCategoryBase {
    modifiedBy: string;
}
