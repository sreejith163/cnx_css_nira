export class SchedulingAgents {
    employeeId: number;
    firstName: string;
    lastName: string;
    isChecked: boolean;
}
