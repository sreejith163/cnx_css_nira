export class ManagerExcelData {
    EmployeeId: number;
    Date: string;
    ActivityCode: string;
    StartTime: string;
    EndTime: string;
}
