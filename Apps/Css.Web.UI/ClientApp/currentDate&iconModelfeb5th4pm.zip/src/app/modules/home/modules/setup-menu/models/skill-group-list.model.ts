export class SkillGroupList {
    id: number;
    skillGroup: string;
    createdDate: string;
    createdBy: string;
    modifiedBy: string;
    modifiedDate: string;
  }
