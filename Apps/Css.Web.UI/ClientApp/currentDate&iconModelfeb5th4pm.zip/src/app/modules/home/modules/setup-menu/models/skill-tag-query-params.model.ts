import { QueryStringParameters } from 'src/app/shared/models/query-string-parameters.model';

export class SkillTagQueryParams extends QueryStringParameters {
    clientId: number;
    clientLobGroupId: number;
    skillGroupId: number;
}
