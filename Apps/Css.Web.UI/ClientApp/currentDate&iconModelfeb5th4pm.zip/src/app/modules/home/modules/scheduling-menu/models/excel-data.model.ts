export class ExcelData {
    EmployeeId: number;
    StartDate: string;
    EndDate: string;
    ActivityCode: string;
    StartTime: string;
    EndTime: string;
}
