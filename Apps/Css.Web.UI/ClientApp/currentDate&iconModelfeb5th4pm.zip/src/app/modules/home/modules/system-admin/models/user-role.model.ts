export class UserRole {
    id: number;
    role: string;
}
