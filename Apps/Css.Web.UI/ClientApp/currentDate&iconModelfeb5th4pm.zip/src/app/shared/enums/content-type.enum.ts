export enum ContentType {
    String,
    Html
}
