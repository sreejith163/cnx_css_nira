export enum ComponentOperation {
    Add,
    Edit,
    Delete
}
