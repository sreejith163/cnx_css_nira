import { TranslationBase } from './translation-base.model';

export class AddTranslation extends TranslationBase {
    createdBy: string;
}
