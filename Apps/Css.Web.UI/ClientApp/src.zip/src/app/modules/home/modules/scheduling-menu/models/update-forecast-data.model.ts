
import { Forecast } from './forecast.model';

export class UpdateForecastData {
    
    
    forecastData: Forecast[];

}
