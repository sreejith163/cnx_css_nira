export class DateRangeQueryParms {
    dateFrom: string;
    dateTo: string;
}
