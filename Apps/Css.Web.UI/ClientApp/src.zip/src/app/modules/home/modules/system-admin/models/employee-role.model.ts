export class EmployeeRole {
    roleId: number;
    name: string;
}
