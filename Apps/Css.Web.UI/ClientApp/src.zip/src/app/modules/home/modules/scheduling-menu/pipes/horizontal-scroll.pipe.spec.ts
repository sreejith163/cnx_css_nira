import { HorizontalScrollPipe } from './horizontal-scroll.pipe';

describe('HorizontalScrollPipe', () => {
  it('create an instance', () => {
    const pipe = new HorizontalScrollPipe();
    expect(pipe).toBeTruthy();
  });
});
