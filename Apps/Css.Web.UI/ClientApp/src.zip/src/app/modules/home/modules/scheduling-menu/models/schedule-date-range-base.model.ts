export class ScheduleDateRangeBase {
    dateFrom: Date;
    dateTo: Date;
}
