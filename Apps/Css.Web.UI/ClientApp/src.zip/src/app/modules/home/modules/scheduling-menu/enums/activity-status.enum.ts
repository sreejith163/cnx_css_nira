export enum ActivityStatus {
    Created,
    Updated,
    Deleted
}
