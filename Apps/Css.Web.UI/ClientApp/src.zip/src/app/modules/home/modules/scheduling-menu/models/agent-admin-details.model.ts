import { AgentAdminBase } from './agent-admin-base.model';

export class AgentAdminDetails extends AgentAdminBase {
    createdDate: string;
    createdBy: string;
    modifiedDate: string;
    modifiedBy: string;
}
