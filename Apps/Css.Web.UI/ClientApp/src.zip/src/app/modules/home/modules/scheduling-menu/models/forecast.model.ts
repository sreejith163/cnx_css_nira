export class Forecast {
      
      
        time: string;
        forecastedContact: number;
        aht: number;
        forecastedReq: number;
        scheduledOpen: number;
}
