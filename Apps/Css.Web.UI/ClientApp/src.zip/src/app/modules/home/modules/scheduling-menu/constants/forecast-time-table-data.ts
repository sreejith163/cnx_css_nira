import { Forecast } from '../models/forecast.model';


export const ForecastExcelExportData: Forecast[] = [
   
   
    {
        Time: '12:30 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',
        ScheduledOpen '0'
    },
    {
        Time: '1:00 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',
        ScheduledOpen '0'

    },
    {
        Time: '1:30 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    },
    {
        Time: '2:00 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    },
    {
        Time: '2:30 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    },
    {
        Time: '3:00 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    },
    {
        Time: '3:30 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    },
    {
        Time: '4:00 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    },
    {
        Time: '4:30 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    },
    {
        Time: '5:00 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    },
    {
        Time: '5:30 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    },
    {
        Time: '6:00 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    },
    {
        Time: '6:30 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    },
    {
        Time: '7:00 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    },
    {
        Time: '7:30 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    },
    {
        Time: '8:00 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    },
    {
        Time: '8:30 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    },
    {
        Time: '9:00 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '9:30 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '10:00 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '10:30 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '11:00 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '11:30 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '12:00 AM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '12:30 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '1:00 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '1:30 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '2:00 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '2:30 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '3:00 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '3:30 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '4:00 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    } ,
    {
        Time: '4:30 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '5:00 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '5:30 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '6:00 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '6:30 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '7:00 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '7:30 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '8:00 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '8:30 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '9:00 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '9:30 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '10:00 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '10:30 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '11:00 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    ,
    {
        Time: '11:30 PM',
        ForecastedContact: '300',
        AHT: '300',
        ForecastedReq: '20',

    }
    
    
];
