export enum ActivityOrigin {
    CSS,
    UDW
}
