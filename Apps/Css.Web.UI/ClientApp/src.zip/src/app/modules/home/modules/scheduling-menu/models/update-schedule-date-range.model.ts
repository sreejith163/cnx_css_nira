export class UpdateScheduleDateRange {
    oldDateFrom: Date;
    oldDateTo: Date;
    newDateFrom: Date;
    newDateTo: Date;
    modifiedBy: string;
}
