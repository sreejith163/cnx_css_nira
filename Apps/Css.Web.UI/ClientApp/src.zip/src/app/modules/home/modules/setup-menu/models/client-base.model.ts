export class ClientBaseModel {
    id: number;
    refId: number;
    name: string;
}
