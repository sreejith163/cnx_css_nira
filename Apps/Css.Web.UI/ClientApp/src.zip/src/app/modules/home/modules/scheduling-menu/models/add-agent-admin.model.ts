import { AgentAdminBase } from './agent-admin-base.model';

export class AddAgentAdmin extends AgentAdminBase {
    createdBy: string;
}
