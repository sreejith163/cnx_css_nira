import { AgnetScheduleChartRange } from './agnet-schedule-chart-range.model';

export class AgentScheduleChartResponse {

    id: string;
    agentScheduleRange: AgnetScheduleChartRange;
}
