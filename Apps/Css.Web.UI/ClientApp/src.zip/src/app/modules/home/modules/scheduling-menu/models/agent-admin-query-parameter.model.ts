import { QueryStringParameters } from 'src/app/shared/models/query-string-parameters.model';

export class AgentAdminQueryParameter extends QueryStringParameters {
    agentSchedulingGroupId?: number;
}
