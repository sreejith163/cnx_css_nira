export enum AgentScheduleType {
    Scheduling,
    SchedulingManager
}
