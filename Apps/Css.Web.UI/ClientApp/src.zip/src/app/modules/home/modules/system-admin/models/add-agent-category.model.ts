import { AgentCategoryBase } from './agent-category-base.model';

export class AddAgentCategory extends AgentCategoryBase {
    createdBy: string;
}
