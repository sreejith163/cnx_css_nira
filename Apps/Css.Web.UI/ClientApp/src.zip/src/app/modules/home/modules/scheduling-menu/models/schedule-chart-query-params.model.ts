export class ScheduleChartQueryParams {
    date: string;
    day: number;
    agentScheduleType: number;
}
