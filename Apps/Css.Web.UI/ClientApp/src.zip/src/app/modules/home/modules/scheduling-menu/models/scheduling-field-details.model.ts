import { ActivityLogManager } from './activity-log-manager.model';
import { ActivityLogRange } from './activity-log-range.model';

export class SchedulingFieldDetails {
    activityLogRange: ActivityLogRange;
    activityLogManager: ActivityLogManager;
}
