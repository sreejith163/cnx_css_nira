import { ScheduleChart } from './schedule-chart.model';

export class AgentScheduleManagerChart {
    charts: ScheduleChart[];

    constructor() {
        this.charts = [];
    }
}
