export class CopyChartBase {
    employeeIds: number[];
    agentSchedulingGroupId: number;
    activityOrigin: number;
    modifiedUser: number;
    modifiedBy: string;
}
