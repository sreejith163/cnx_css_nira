import { CopyChartBase } from './copy-chart-base.model';

export class CopyAgentScheduleChart extends CopyChartBase {
    dateFrom: Date;
    dateTo: Date;
}
