export class Employee {
    id: number;
    sso: string;
    employeeId: number;
    firstname: string;
    lastname: string;
    roleName: string;
}
