export class SchedulingCodeType {
    schedulingCodeTypeId: number;
}
