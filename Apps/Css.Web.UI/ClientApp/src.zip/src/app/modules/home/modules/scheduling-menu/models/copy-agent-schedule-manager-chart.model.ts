import { CopyChartBase } from './copy-chart-base.model';

export class CopyAgentScheduleManagerChart extends CopyChartBase {
    date: Date;
}
