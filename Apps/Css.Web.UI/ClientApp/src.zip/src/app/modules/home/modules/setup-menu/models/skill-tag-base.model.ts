export class SkillTagBase {
    id: number;
    refId: number;
    name: string;
    clientId: number;
    clientName: string;
    clientLobGroupId: number;
    clientLobGroupName: string;
    skillGroupId: number;
    skillGroupName: string;
}
