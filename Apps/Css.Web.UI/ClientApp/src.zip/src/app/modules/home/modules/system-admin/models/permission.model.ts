export class Permission {
    employeeId: number;
    firstName: string;
    lastName: string;
}
