export class LoggedUserInfo {
    uid: string;
    sso: string;
    displayName: string;
    employeeId: string;
}
