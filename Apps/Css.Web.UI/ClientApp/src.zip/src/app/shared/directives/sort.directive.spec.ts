import { SortDirective } from './sort.directive';

describe('SortDirective', () => {
  it('should create an instance', () => {
    const directive = new SortDirective();
    expect(directive).toBeTruthy();
  });
});
