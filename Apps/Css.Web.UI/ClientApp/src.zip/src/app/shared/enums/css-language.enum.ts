export enum CssLanguage {
    English = 1,
    EspañolSpanish = 2,
    French = 3,
    Italian = 4,
    Dutch = 5,
    DeutschGerman = 6,
    Japanese = 7,
    Russian = 8,
    ChineseSimplified = 9,
    ChineseTraditional = 10
}
