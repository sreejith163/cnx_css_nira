export enum ActivityType {
    Client,
    ClientLobGroup,
    SkillGroup,
    SkillTag,
    AgentSchedulingGroup,
    AgentAdmin,
    SchedulingGrid,
    SchedulingManagerGrid
}
