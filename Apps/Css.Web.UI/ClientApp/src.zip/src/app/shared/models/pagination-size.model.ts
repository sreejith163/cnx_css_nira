export class PaginationSize {
    count: number;
    text: string;
}
