export class TimeZone {
    id: number;
    value: string;
}
