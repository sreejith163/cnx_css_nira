
export class LanguagePreference {
    languagePreference: string;
}
