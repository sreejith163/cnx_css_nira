export class MoveAgentAdminParameters {
    agentAdminIds: string [];
    sourceSchedulingGroupId: number;
    destinationSchedulingGroupId: number;
    modifiedBy: string;
}
