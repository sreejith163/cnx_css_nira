import { AgentMyScheduleDetails } from "./agent-myschedule-details.model";

export class AgentMyScheduleResponse{
    agentMySchedules: AgentMyScheduleDetails [];
}