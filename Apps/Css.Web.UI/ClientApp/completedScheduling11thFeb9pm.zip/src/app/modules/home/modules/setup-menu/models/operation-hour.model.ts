export class OperationHour {
  day: number;
  operationHourOpenTypeId: number;
  from?: Date;
  to?: Date;
}
