export enum DataType {
    AlphaNumeric = 1,
    Date = 2,
    Numeric = 3
}
