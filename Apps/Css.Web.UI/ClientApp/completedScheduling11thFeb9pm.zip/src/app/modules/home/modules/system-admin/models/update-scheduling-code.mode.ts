import { SchedulingCodeAttributes } from './scheduling-code-attributes.model';

export class UpdateSchedulingCode extends SchedulingCodeAttributes {
    modifiedBy: string;
}
