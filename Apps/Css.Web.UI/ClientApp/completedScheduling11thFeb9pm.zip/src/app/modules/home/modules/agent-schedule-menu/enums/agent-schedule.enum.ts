export enum DAY_MS {
    util = 60 * 60 * 24 * 1000   
};