export enum SchedulingStatus {
    'Approved' = 1,
    'Pending Schedule' = 2,
    'Rejected' = 3
}
