import { AgentScheduleChart } from './agent-schedule-chart.model';

export class UpdateAgentschedulechart {
    agentScheduleCharts: AgentScheduleChart[];
    activityOrigin: number;
    modifiedUser: number;
    modifiedBy: string;
}
