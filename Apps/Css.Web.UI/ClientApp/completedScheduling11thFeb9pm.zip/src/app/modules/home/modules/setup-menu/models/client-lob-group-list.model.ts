export class ClientLOBGroupList {
  id: number;
  clientLOBGroup: string;
  createdDate: string;
  createdBy: string;
  modifiedBy: string;
  modifiedDate: string;
}
