import { AgentAdminAgentGroup } from './agent-admin-agent-group.model';

export class AgentAdminAgentData {
    group: AgentAdminAgentGroup;
}
