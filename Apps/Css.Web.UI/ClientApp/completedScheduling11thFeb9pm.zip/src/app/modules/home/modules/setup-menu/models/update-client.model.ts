import { ClientBaseModel } from './client-base.model';

export class UpdateClient extends ClientBaseModel {
    ModifiedBy: string;
}
