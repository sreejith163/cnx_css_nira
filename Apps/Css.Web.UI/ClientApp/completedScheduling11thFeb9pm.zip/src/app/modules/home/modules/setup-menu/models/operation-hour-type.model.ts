export class OperationHourType {
    id: number;
    open: string;
}
