import { KeyValue } from 'src/app/shared/models/key-value.model';

export class VariableResponse extends KeyValue {
    description: string;
}
