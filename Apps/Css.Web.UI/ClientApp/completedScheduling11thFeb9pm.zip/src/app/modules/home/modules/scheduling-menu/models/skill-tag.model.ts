export class SkillTag {
    id: number;
    skillTag: string;
    createdDate: string;
    createdBy: string;
    modifiedBy: string;
    modifiedDate: string;
  }
