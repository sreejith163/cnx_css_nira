import { ScheduleChart } from './schedule-chart.model';

export class AgentScheduleManagerChart {
    date: Date;
    charts: ScheduleChart[];

    constructor() {
        this.charts = [];
    }
}
