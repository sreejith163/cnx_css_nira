export class KeyValue {
    id: number;
    value: string;
}
