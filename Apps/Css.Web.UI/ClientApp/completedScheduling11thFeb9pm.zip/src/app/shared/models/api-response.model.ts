export class ApiResponseModel {
    id: number;
    message: string;
}
