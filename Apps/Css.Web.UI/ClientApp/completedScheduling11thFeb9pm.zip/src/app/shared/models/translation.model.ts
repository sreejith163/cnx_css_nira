export class Translation {
    variableId: string;
    menu: string;
    description: string;
    language: string;
    translation: string;
    createdBy: string;
    createdDate: string;
    modifiedBy: string;
    modifiedDate: string;
}
