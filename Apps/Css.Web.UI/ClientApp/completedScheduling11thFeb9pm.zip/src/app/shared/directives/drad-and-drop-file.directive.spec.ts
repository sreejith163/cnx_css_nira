import { DradAndDropFileDirective } from './drad-and-drop-file.directive';

describe('DradAndDropFileDirective', () => {
  it('should create an instance', () => {
    const directive = new DradAndDropFileDirective();
    expect(directive).toBeTruthy();
  });
});
